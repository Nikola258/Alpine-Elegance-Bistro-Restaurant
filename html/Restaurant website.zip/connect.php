<?php
session_start();
?>

<?php

// Database connection parameters
$host = 'localhost';
$dbname = 'Menu';
$username = 'root';
$password = 'rootpassword';

// Create a new PDO instance
try {
    $pdo = new PDO("mysqli:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";

    // Prepare and execute a SQL query
    $stmt = $pdo->prepare("SELECT * FROM Menu");
    $stmt->execute();

    // Fetch the results as an associative array
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Output the results
    foreach ($results as $row) {
        echo "<div class='name'>" . $row['name'] . "</div>";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">

    <title>Document</title>
</head>
<body>

    <?php

        $connection = new PDO("mysql:host=localhost;dbname=Menu", "root", "rootpassword");


        $sql = "SELECT * FROM Menu";
        $stmt = $connection->query($sql);

        while($Menu = $stmt->fetch()){
            echo "<div class='name'>" . $Menu["name"] . "</div>";
            }
    ?>

    <ul>
        <li><a href="#">Verwijder gerecht</a></li>
        <li><a href="Add.php">Voeg nieuwe gerecht toe</a></li>
        <li><a href="#">Prijs veranderen</a></li>
    </ul>

</body>
</html>