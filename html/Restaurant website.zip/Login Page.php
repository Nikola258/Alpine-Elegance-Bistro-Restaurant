<?php 
    session_start();
if (isset($_POST['login'])) {
    if ($_POST['username'] == "admin" && $_POST['password'] == "123") {
        $_SESSION['username'] = "admin";
        header(header:"Location: connect.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="connect.php" method="post">
        <h1>Login</h1>
        <div>
            <label for="username">Username:</label>
            <input type="text" name="username" id="username">
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password">
        </div>
        <section>
            <button type="submit">Login</button>
        </section>
    </form>



</body>
</html>