<?php 
require_once "connect.php" 
?>

<form method="post" action="AddLogic.php">
    <label>Naam</label>
    <input type="text" name="name" placeholder="name">

    <label>prijs</label>
    <input type="text" name="price" placeholder="price">

    <input type="submit" value="Voeg nieuwe gerecht toe">
</form>